#ifndef HOLBERTON_H
#define HOLBERTON_H

int wildcmp(char *s1, char *s2);

#endif /* HOLBERTON_H */
