shit project
